package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

import java.util.StringTokenizer;

public class VikramKrishnaswamy extends AppCompatActivity {

    Button[] buttons = new Button[16];


    static String expression = "";

    double answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttons[0] = findViewById(R.id.button14);
        buttons[1] = findViewById(R.id.button);
        buttons[2] = findViewById(R.id.button2);
        buttons[3] = findViewById(R.id.button3);
        buttons[4] = findViewById(R.id.button5);
        buttons[5] = findViewById(R.id.button6);
        buttons[6] = findViewById(R.id.button7);
        buttons[7] = findViewById(R.id.button9);
        buttons[8] = findViewById(R.id.button10);
        buttons[9] = findViewById(R.id.button11);

        buttons[10] = findViewById(R.id.button4); //+ sign
        buttons[11] = findViewById(R.id.button8); //- sign
        buttons[12] = findViewById(R.id.button12); //* sign
        buttons[13] = findViewById(R.id.button16); // Division sign

        buttons[14] = findViewById(R.id.button15);// = button
        buttons[15] = findViewById(R.id.button13);// CLEAR button

        View back = findViewById(R.id.mainLayout);
        back.setBackgroundColor(Color.BLACK);

        TextView exp = findViewById(R.id.textView4);
        exp.setTextColor(Color.WHITE);

        TextView appName = findViewById(R.id.textView);
        appName.setTextColor(Color.WHITE);

        TextView name = findViewById(R.id.textView2);
        name.setTextColor(Color.WHITE);

        TextView block = findViewById(R.id.textView3);
        block.setTextColor(Color.WHITE);

        for(int i = 0; i < buttons.length; i++){
            buttons[i].setTextColor(Color.WHITE);
            if(i!= 10 && i!= 11 && i != 12 && i != 13 && i != 14 && i !=15) {
                buttons[i].setBackgroundColor(Color.GRAY);

            } else{
                buttons[i].setBackgroundColor(Color.RED);
            }
        }

        for(int i = 0; i < buttons.length; i++){
            int finalI = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(finalI == 14){
                        solve(expression);
                    } else if (finalI == 15){
                        expression = "";
                        TextView exp = findViewById(R.id.textView4);
                        exp.setText((CharSequence) expression);
                    }
                    else{
                        expression +=  (String)buttons[finalI].getText();
                        System.out.println(expression);
                       // Log.d("MYERRPR", expression+"");
                        TextView exp = findViewById(R.id.textView4);
                        exp.setText((CharSequence) expression);
                    }
                }
            });
        }

    }

    public void solve(String s){

        StringTokenizer st = new StringTokenizer(s, "+-*/", true);

        ArrayList<String> bd = new ArrayList<String>();

        while(st.hasMoreTokens()){
            bd.add(st.nextToken());
        }

        try {
            while(bd.contains( "*")) {
                int i = bd.indexOf("*");
                String tempAns = String.valueOf(Double.parseDouble(bd.get(i-1)) * Double.parseDouble(bd.get(i+1)));
                bd.remove(i-1);
                bd.remove(i-1);
                bd.remove(i-1);
                bd.add(i-1, tempAns);
            }

            while(bd.contains( "/")) {
                int i = bd.indexOf("/");
                if(Double.parseDouble(bd.get(i+1)) != 0){
                    double ans = Double.parseDouble(bd.get(i-1)) / Double.parseDouble(bd.get(i+1));
                    String tempAns = String.valueOf(ans);
                    bd.remove(i-1);
                    bd.remove(i-1);
                    bd.remove(i-1);
                    bd.add(i-1, tempAns);
                } else{
                    throw new ArithmeticException();
                }
            }

            while(bd.contains("+")) {
                int i = bd.indexOf("+");
                String tempAns = String.valueOf(Double.parseDouble(bd.get(i-1)) + Double.parseDouble(bd.get(i+1)));
                bd.remove(i-1);
                bd.remove(i-1);
                bd.remove(i-1);
                bd.add(i-1, tempAns);
            }

            while(bd.contains("-")) {
                int i = bd.indexOf("-");
                String tempAns = String.valueOf(Double.parseDouble(bd.get(i-1)) - Double.parseDouble(bd.get(i+1)));
                bd.remove(i-1);
                bd.remove(i-1);
                bd.remove(i-1);
                bd.add(i-1, tempAns);
            }


            TextView exp = findViewById(R.id.textView4);
            exp.setText((CharSequence) bd.get(0));
            expression = bd.get(0);
            //Log.d("OTHERERROR",expression+"");
            exp.setText(expression);
            //System.out.println(expression);
           // System.out.println(bd);

        } catch(ArithmeticException e){
            TextView exp = findViewById(R.id.textView4);
            exp.setText((CharSequence) ("ERROR. Undefined"));
        }
        catch(Exception e){

            TextView exp = findViewById(R.id.textView4);
            exp.setText((CharSequence) ("ERROR. Try again"));

        }


    }

}